package com.mytaxi.android_demo.pages;

import android.util.Log;

import com.mytaxi.android_demo.R;
import com.mytaxi.android_demo.model.User;
import com.mytaxi.android_demo.pages.base.BasePage;

public class AuthenticationPage extends BasePage {

    public int getUserId() {
        return R.id.edt_username;
    }

    public int getPassword() {
        return R.id.edt_password;
    }

    public int getLoginBtn() {
        return R.id.btn_login;
    }

    public boolean login (User user) {
        boolean isLogin = false ;
        try {
            typeTextIntoElement( findElementWithId( getUserId() ), user.getUserId() );
            typeTextIntoElement( findElementWithId( getPassword() ), user.getPassword() );
            clickOnElement(findElementWithId(getLoginBtn()));

            isLogin = true ;
        } catch (Exception ex) {
            Log.e("Error:", "AuthenticationPage.login");
        }

        return isLogin;
    }
}
