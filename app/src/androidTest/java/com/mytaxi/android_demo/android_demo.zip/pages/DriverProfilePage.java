package com.mytaxi.android_demo.pages;

import android.util.Log;

import com.mytaxi.android_demo.R;
import com.mytaxi.android_demo.pages.base.BasePage;

public class DriverProfilePage extends BasePage {


    public int getFabBtn() {
        return R.id.fab;
    }

    public int getDriverName(){
        return R.id.textViewDriverName;
    }

    public boolean callDriver () {
        boolean callDriver = false ;
        try {
            clickOnElement(findElementWithId(getFabBtn()));

            callDriver = true ;

        } catch (Exception ex) {
            Log.e("Error:", "AuthenticationPage.login");
        }

        return callDriver;
    }

}
