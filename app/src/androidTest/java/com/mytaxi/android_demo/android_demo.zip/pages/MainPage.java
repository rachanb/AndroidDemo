package com.mytaxi.android_demo.pages;

import android.util.Log;

import com.mytaxi.android_demo.R;
import com.mytaxi.android_demo.pages.base.NavigationPage;

public class MainPage extends NavigationPage {

    public int getTxtSearch() {
        return R.id.textSearch;
    }

    public String searchDriver(String driverNameStart) {

        try {
            clickOnElement(findElementWithId(getTxtSearch()));
            waitOnPage();
            typeTextIntoElement(findElementWithId(getTxtSearch()),driverNameStart);
            clickOnElement(findInRoot (findElementWithText("Sarah") ));
            waitOnPage();

        } catch (Exception ex) {
            Log.e("Error:", "MainPage.searchDriver failed");
        }
        return null;

    }
}
