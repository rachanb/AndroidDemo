package com.mytaxi.android_demo.pages.base;

import com.mytaxi.android_demo.R;

public class NavigationPage extends  BasePage{

    public int getNavigationButtonOpen() {
        return R.string.navigation_drawer_open;
    }

    public int getNavigationButtonClose() {
        return R.string.navigation_drawer_close;
    }

    public int getNavigatedUserLabel() {
        return R.id.nav_username;
    }
}
