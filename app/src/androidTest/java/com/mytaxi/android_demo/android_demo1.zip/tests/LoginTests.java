package com.mytaxi.android_demo.tests;

import static android.support.test.espresso.matcher.ViewMatchers.*;
import static android.support.test.espresso.assertion.ViewAssertions.*;

import android.content.Context;
import android.support.test.InstrumentationRegistry;
import android.support.test.rule.ActivityTestRule;

import com.mytaxi.android_demo.activities.DriverProfileActivity;
import com.mytaxi.android_demo.activities.MainActivity;
import com.mytaxi.android_demo.model.User;
import com.mytaxi.android_demo.pages.AuthenticationPage;
import com.mytaxi.android_demo.pages.DriverProfilePage;
import com.mytaxi.android_demo.pages.MainPage;


import org.junit.Rule;
import org.junit.Test;

public class LoginTests extends BaseTest{

    MainPage mainPage;
    DriverProfilePage driverProfilePage;
/*    @Rule
    public ActivityTestRule<MainActivity> activityRule = new ActivityTestRule<>(MainActivity.class);*/

    @Test
    public void Test1_verifyAuthentication(){
        AuthenticationPage authenticationPage = new AuthenticationPage();
        User user = new User("crazydog335","venture");
        if(authenticationPage.login(user)){
           mainPage = new MainPage();
           mainPage.getLoggedInUser().check(matches(withText(user.getUserId())));


        }
    }

   /* @Test
    public void Test2_verifySearchDriver(){
        mainPage = new MainPage();
        mainPage.searchDriver("sa","Sarah Scott");
        driverProfilePage = new DriverProfilePage();
        driverProfilePage.getDriverName().check(matches(withText("Sarah Scott")));

        driverProfilePage.callDriver();
    }*/






}
