package com.mytaxi.android_demo.tests;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Instrumentation;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;

import android.support.test.InstrumentationRegistry;
import android.support.test.espresso.intent.Intents;
import android.support.test.rule.ActivityTestRule;
import android.util.Log;

import com.mytaxi.android_demo.activities.MainActivity;
import com.mytaxi.android_demo.pages.DriverProfilePage;
import com.mytaxi.android_demo.pages.MainPage;

import org.junit.Rule;
import org.junit.Test;

import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.intent.matcher.IntentMatchers.hasAction;
import static android.support.test.espresso.intent.matcher.IntentMatchers.hasPackage;
import static android.support.test.espresso.intent.matcher.IntentMatchers.isInternal;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static android.support.test.espresso.intent.Intents.intending;
import static android.support.test.espresso.intent.matcher.IntentMatchers.toPackage;
import static android.support.test.espresso.intent.Intents.intended;

public class MainScreenTests extends BaseTest{

    MainPage mainPage;
    DriverProfilePage driverProfilePage;

    @Test
    public void Test2_verifySearchDriver() throws InterruptedException{
        mainPage = new MainPage();
        mainPage.searchDriver("sa","Sarah Scott");
        driverProfilePage = new DriverProfilePage();
        driverProfilePage.getDriverName().check(matches(withText("Sarah Scott")));

        Context context = InstrumentationRegistry.getContext();

        Log.e("Test2_verifySearchDriver()", "--- CLICKING ON DIAL ICON ---" );
        Intents.init();
        Intent intent = new Intent();
        intent.setPackage()
        Instrumentation.ActivityResult result =
                new Instrumentation.ActivityResult(Activity.RESULT_OK, intent);
        intending(toPackage("com.google.dialer")).respondWith(result);

        Log.e("Test2_verifySearchDriver()", "--- $$$ INTENT COMPONENT $$$ ---"+intent.getComponent().toString() );
        Log.e("Test2_verifySearchDriver()", "--- $$$ INTENT PACKAGE $$$ ---"+intent.getPackage() );

        //CALL DRIVER
        Log.e("Test2_verifySearchDriver()", "--- CLICKING ON DIAL ICON ---" );
        driverProfilePage.callDriver();

        Thread.sleep(1000);
        intended(hasPackage("com.google.android.dialer"));
        intended(toPackage("com.google.android.dialer"));
        Context targetContext2 = InstrumentationRegistry.getInstrumentation().getTargetContext();
        Intents.release();

    }

    @Test
    public void callDriver()
    {

    }


}
